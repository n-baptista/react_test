import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import UserInformation from './UserInformation';

const GHAPI = 'https://api.github.com/users/example';

class App extends Component {

  constructor(props) {
    super(props);
    this.state = { 
	user: { avatar_url : '',
	        bio : null,
	        blog : '',
	        company : null,
	        created_at : '',
		email : null,
		events_url : '',
		followers : 0,
		followers_url : '',
		following : 0,
		following_url : '',
		gists_url : '',
	        gravatar_url : '',
		hireable : null,
	        html_url : '',
	        id : 0,
		location : null,
	        login : '',
		name : null,
		node_id : '',
		organizations_url: '',
		public_gists : 0,
		public_repos : 0,
		received_events_url : '',
		repos_url : '',
		site_admin : false,
		starred_url : '',
		subscripstions_url : '',
		type : '',
		updated_at : '',
		url : ''
	},
        clicked : false }
  }

  getUserInformation() {
    /*
      To hide the button after being clicked
    */
    fetch(GHAPI)
       .then(res => res.json())
       .then(data => this.setState({user : data, clicked : true}));
  }

  render() {
    return (
      <div className="App">
        <div className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h2>Welcome to React</h2>
        </div>
        <p className="App-intro">
          To get started, edit <code>src/App.js</code> and save to reload.
        </p>
         
          <hr />
          {!this.state.clicked ? <div className="App-intro">
            <p>Click on the button to fetch the user information</p>
            <button onClick={this.getUserInformation.bind(this)}>
              Click me
            </button> 
            <UserInformation /> 
          </div> : <div className="App-intro">
            <div> 
              <p><font size="6">{this.state.user.login}</font></p>
	      <img style={{width: '125px', height: '125px'}} src={this.state.user.avatar_url} alt="Failed to load"/>
	      <p>Followers: {this.state.user.followers}</p>
	      <p>Repos: {this.state.user.public_repos}</p>
	      <p>Following: {this.state.user.following}</p>
	    </div>
          </div>}

      </div>
    );
  }
}

export default App;
