import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import UserInformation from './UserInformation';

const GHAPI = 'https://api.github.com';

class App extends Component {

  constructor(props) {
    super(props);
    this.state = { 
	user: {},
        clicked : false }
  }

  getUserInformation() {
    /*
      TODO: fetch a user from the GitHub API

      TIPS:
       1) The Fetch API provides an interface for
         fetching resources (including across the network).
       2) Maybe you want to update the state here.
    */
    /*
      To hide the button after being clicked
    */
    if(!this.state.clicked)
       this.setState({clicked : true});
    fetch(GHAPI)
       .then(response => response.json())
       .then(data => this.setState({user : data.user}));
  }

  render() {
    return (
      <div className="App">
        <div className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h2>Welcome to React</h2>
        </div>
        <p className="App-intro">
          To get started, edit <code>src/App.js</code> and save to reload.
        </p>
         
          <hr />
          {!this.state.clicked ? <div className="App-intro">
            <p>Click on the button to fetch the user information</p>
            <button onClick={this.getUserInformation.bind(this)}>
              Click me
            </button> 
            <UserInformation /> 
          </div> : <div className="App-intro">
            Has been clicked!
          </div>}

      </div>
    );
  }
}

export default App;
