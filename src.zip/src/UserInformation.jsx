import React from 'react';

const UserInformation = props => (
  <div>
    Display the user information here
  </div>
);

export default UserInformation;
